/*
  ----
    galeriaScroll v2.1.2
  ----
  
  
  AUTOR:
  
    Carlos Eduardo de Souza - http://www.webstandards.blog.br
  
  INSTRUCOES:
  
    Declarar estas variaveis fora do $(document).ready()
    
    var galeriaScroll = {
      idGaleria: 'galeria', // classe identificadora das galerias
      galeriaAnterior: 'anterior', // classe para o link anterior
      galeriaProximo: 'proximo', // classe para o link proximo
      itemGaleria: 'figure', // elemento que contem cada item da galeria
      estruturaGaleria: '.mascara > div', // elemento que sera animado (com margin)
      velocidade:  250, // velocidade da animacao em ms
      paginacao: 'paginacao' // classe usada para a lista da paginacao. Caso nao queira usar paginacao, apague esta linha e retire a ',' da linha acima
    }
  
  OBSERVACOES:
    
    Elemento com a classe "mascara" envolvendo os itens da lista, logo abaixo da galeria. Ex: div.galeria > div.mascara ...
    Classe "inativo" para os elementos nao-clicaveis
    Classe "ativo" para o item da paginacao atual
    
    
*/

$(document).ready(function(){
  
  // Verificando se a paginacao existe
  if(typeof galeriaScroll.paginacao != "undefined"){
    paginacao = true;
  }
  
  $('.' + galeriaScroll.idGaleria).each(function(){
    
    // largura 9999em para nao quebrar a galeria em linhas
    $(galeriaScroll.estruturaGaleria, $(this)).css('width', '9999em');
    
    // inserindo os links de navegacao em cada galeria
    $(this).prepend('<a class="'+ galeriaScroll.galeriaAnterior +'" href="#" title="Anterior">Anterior</a> <a class="' + galeriaScroll.galeriaProximo + '" href="#" title="Pr&oacute;ximo">Pr&oacute;ximo</a>');
    
    // variavel com o valor do ID da galeria
    gAtual = $(this).attr('id');
    
    // criando variavel dinamica
    window["n_" + gAtual] = 0;
    
    // largura do elemento que envolve a galeria
    window["largura_" + gAtual] = $('.mascara', $(this)).width();
    
    // limite de elementos a aparecer na tela, de acordo com a largura total / largura de cada item
    window["limite_" + gAtual] = Math.ceil(window["largura_" + gAtual] / $(galeriaScroll.itemGaleria, $(this)).outerWidth(true));
    
    // elemento da galeria, dentro da galeria especifica
    window["galeria_" + gAtual] = $(galeriaScroll.estruturaGaleria, $(this));
    
    // adicionando class "inativo" para o link anterior, alem de esconder o "proximo" se os itens forem <= que o limite
    $('a.' + galeriaScroll.galeriaAnterior, $(this)).addClass('inativo');
    window["total_" + gAtual] = $(galeriaScroll.itemGaleria, $(this)).length;
    if (window["total_" + gAtual] <= window["limite_" + gAtual]) $('a.'+ galeriaScroll.galeriaProximo, $(this)).addClass('inativo');
    
    // numero de scrolls possiveis
    window["scrolls_" + gAtual] = Math.ceil(window["total_" + gAtual] / window["limite_" + gAtual]) - 1;
    
    // numero de scrolls possiveis
    limiteScrolls = Math.ceil(window["total_" + gAtual] / window["limite_" + gAtual]) - 1;
    
    // criacao da paginacao
    if(paginacao){
      
      // insere o elemento <ol> para a paginacao
      $('#' + gAtual).append('<ol class="'+ galeriaScroll.paginacao +'"></ol>');
      
      // cria os elementos da paginacao de acordo com os scrolls
      var i = 0;
      for (i = 0; i <= limiteScrolls ; i++) {
        var texto = parseInt(i) + 1;
        $('ol.'+ galeriaScroll.paginacao, '#' + gAtual).append('<li><a href="#" title="Navegar na galeria">'+ texto +'</a></li>') 
      }
      
      // classe 'ativo' para o primeiro item da lista
      $('ol.'+ galeriaScroll.paginacao +' li:first', $(this)).addClass('ativo');
      
    };
    
  });
  
  // NAVEGACAO - funcao para scroll na galeria
  function scrollGaleria(direcao, g){
    
    if(galeriaScroll.paginacao){
      // ao clicar na navegacao, retira a classe 'ativo' de todos os itens da paginacao
      $('#'+ g +' ol.'+ galeriaScroll.paginacao +' li').removeClass('ativo');
    }
    
    switch (direcao){
    
      /* 
        Caso a direcao seja 'anterior' tira 1 da variavel a cada clique,
        retira a classe 'inativo' do link 'proximo',
        se a variavel dinamica for = 0 adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaScroll.galeriaAnterior : 
        window["n_" + g] -= 1;
        $('#' + g + ' a.'+ galeriaScroll.galeriaProximo).removeClass('inativo'); 
        if (window["n_" + g] == 0) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        window["galeria_" + g].animate({
          'margin-left' : '+=' + window["largura_" + g] + 'px',
          'margin-right' : '+=' + window["largura_" + g] + 'px'
        }, galeriaScroll.velocidade);
        
        if(galeriaScroll.paginacao){
          // insere a classe 'ativo' no item da paginacao correspondente ao clique
          $('#'+ g +' ol.'+ galeriaScroll.paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
        }
      break;
      
      /* 
        Caso a direcao seja 'proximo' soma 1 da variavel a cada clique,
        mostra o link 'anterior',
        se os cliques atingirem o limite adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaScroll.galeriaProximo : 
        window["n_" + g] += 1;
        $('#' + g + ' a.'+ galeriaScroll.galeriaAnterior).removeClass('inativo');
        if (window["n_" + g] == window["scrolls_" + g]) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        window["galeria_" + g].animate({
          'margin-left' : '-=' + window["largura_" + g] + 'px',
          'margin-right' : '-=' + window["largura_" + g] + 'px'
        }, galeriaScroll.velocidade);
        
        if(galeriaScroll.paginacao){
          // insere a classe 'ativo' no item da paginacao correspondente ao clique
          $('#'+ g +' ol.'+ galeriaScroll.paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
        }
      break;
    }
  }
  
  // scrollPaginacao - funcao para scroll na galeria
  function scrollPaginacao(i, g){
    
    // atualizando a variavel dos cliques
    window["n_" + g] = parseInt(i);
    
    if (window["n_" + g] == 0) { 
      $('#'+ g +' a.' + galeriaScroll.galeriaAnterior).addClass('inativo'); 
      $('#'+ g +' a.' + galeriaScroll.galeriaProximo).removeClass('inativo');
    } else if (window["n_" + g] > 0 || window["n_" + g] <= window["scrolls_" + g]) { 
      $('#'+ g +' a.' + galeriaScroll.galeriaAnterior).removeClass('inativo');
      $('#'+ g +' a.' + galeriaScroll.galeriaProximo).removeClass('inativo');
    }
    
    if (window["n_" + g] == window["scrolls_" + g]) { 
      $('#'+ g +' a.' + galeriaScroll.galeriaProximo).addClass('inativo');
    }
    
    window["galeria_" + g].animate({
      'margin-left' : '-' + window["largura_" + g] * i + 'px',
      'margin-right' : '-' + window["largura_" + g] * i + 'px'
    }, galeriaScroll.velocidade);
    
  }
  
  $('.' + galeriaScroll.idGaleria +' a.'+ galeriaScroll.galeriaAnterior + ', '+ '.' + galeriaScroll.idGaleria +' a.' + galeriaScroll.galeriaProximo).click(function(){
    
    // se o link nao tiver a classe "inativo" executa a funcao da galeria
    if(!$(this).hasClass('inativo')){
      scrollGaleria($(this).attr('class'), $(this).parent().attr('id'));
    }
    return false;
    
  });
  
  if(galeriaScroll.paginacao){
    $('.' + galeriaScroll.idGaleria +' ol.'+ galeriaScroll.paginacao +' li a').click(function(){
      
      // id da galeria que envolve a paginacao clicada
      var id = $(this).parent().parent().parent().attr('id');
      
      // executa a funcao de scroll da paginacao
      scrollPaginacao($(this).parent().index(), id);
      
      // remove a classe ativo e insere no item especifico
      $('#' + id + ' ol.'+ galeriaScroll.paginacao +' li').removeClass('ativo');
      $(this).parent().addClass('ativo');
      
      return false;
      
    });
  }
  
});