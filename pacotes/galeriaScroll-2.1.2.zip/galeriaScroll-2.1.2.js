/*
  ----
    galeriaScroll v2.1.2
  ----
  
  AUTOR:
  
    Carlos Eduardo de Souza - http://www.webstandards.blog.br
  
  INSTRUCOES:
  
  Declarar estas variaveis ANTES de chamar o script da galeria:
  
    idGaleria = '.galeria'; // classe identificadora das galerias
    galeriaAnterior = 'anterior'; // classe para o link anterior
    galeriaProximo = 'proximo'; // classe para o link proximo
    itemGaleria = 'ul > li'; // elemento que contem cada item da galeria
    estruturaGaleria = '.mascara > ul'; // elemento que sera animado (com margin)
    velocidade = 250;
    paginacao = 'paginacao'; // caso nao queira usar paginacao, apague esta linha
  
  OBSERVACOES:
    
    div.mascara envolvendo os itens da lista, logo abaixo da galeria. Ex: div.galeria > div.mascara ...
    Classe "inativo" para os elementos nao-clicaveis
    Classe "ativo" para o item da paginacao atual
    
*/

$(document).ready(function(){
  
  $(idGaleria).each(function(){
    
    // largura 9999em para nao quebrar a galeria em linhas
    $(estruturaGaleria, $(this)).css('width', '9999em');
    
    // inserindo os links de navegacao em cada galeria
    $(this).prepend('<a class="'+ galeriaAnterior +'" href="#" title="Anterior">Anterior</a> <a class="' + galeriaProximo + '" href="#" title="Pr&oacute;ximo">Pr&oacute;ximo</a>');
    
    // variavel com o valor do ID da galeria
    gAtual = $(this).attr('id');
    
    // criando variavel dinamica
    window["n_" + gAtual] = 0;
    
    // largura do elemento que envolve a galeria
    window["largura_" + gAtual] = $('.mascara', $(this)).width();
    
    // limite de elementos a aparecer na tela, de acordo com a largura total / largura de cada item
    window["limite_" + gAtual] = Math.ceil(window["largura_" + gAtual] / $(itemGaleria, $(this)).outerWidth(true));
    
    // elemento da galeria, dentro da galeria especifica
    window["galeria_" + gAtual] = $(estruturaGaleria, $(this));
    
    // adicionando class "inativo" para o link anterior, alem de esconder o "proximo" se os itens forem <= que o limite
    $('a.' + galeriaAnterior, $(this)).addClass('inativo');
    window["total_" + gAtual] = $(itemGaleria, $(this)).length;
    if (window["total_" + gAtual] <= window["limite_" + gAtual]) $('a.'+ galeriaProximo, $(this)).addClass('inativo');
    
    // numero de scrolls possiveis
    window["scrolls_" + gAtual] = Math.ceil(window["total_" + gAtual] / window["limite_" + gAtual]) - 1;
    
    // numero de scrolls possiveis
    limiteScrolls = Math.ceil(window["total_" + gAtual] / window["limite_" + gAtual]) - 1;
    
    // criacao da paginacao
    if(typeof paginacao != "undefined"){
      
      // insere o elemento <ol> para a paginacao
      $('#' + gAtual).append('<ol class="'+ paginacao +'"></ol>');
      
      // cria os elementos da paginacao de acordo com os scrolls
      var i = 0;
      for (i = 0; i <= limiteScrolls ; i++) {
        var texto = parseInt(i) + 1;
        $('ol.'+ paginacao, '#' + gAtual).append('<li><a href="#" title="Navegar na galeria">'+ texto +'</a></li>') 
      }
      
      // classe 'ativo' para o primeiro item da lista
      $('ol.'+ paginacao +' li:first', $(this)).addClass('ativo');
      
    };
    
  });
  
  // NAVEGACAO - funcao para scroll na galeria
  function scrollGaleria(direcao, g){
    
    if(typeof paginacao != "undefined"){
      // ao clicar na navegacao, retira a classe 'ativo' de todos os itens da paginacao
      $('#'+ g +' ol.'+ paginacao +' li').removeClass('ativo');
    }
    
    switch (direcao){
    
      /* 
        Caso a direcao seja 'anterior' tira 1 da variavel a cada clique,
        retira a classe 'inativo' do link 'proximo',
        se a variavel dinamica for = 0 adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaAnterior : 
        window["n_" + g] -= 1;
        $('#' + g + ' a.'+ galeriaProximo).removeClass('inativo'); 
        if (window["n_" + g] == 0) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        window["galeria_" + g].animate({
          'margin-left' : '+=' + window["largura_" + g] + 'px',
          'margin-right' : '+=' + window["largura_" + g] + 'px'
        }, velocidade);
        
        if(typeof paginacao != "undefined"){
          // insere a classe 'ativo' no item da paginacao correspondente ao clique
          $('#'+ g +' ol.'+ paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
        }
      break;
      
      /* 
        Caso a direcao seja 'proximo' soma 1 da variavel a cada clique,
        mostra o link 'anterior',
        se os cliques atingirem o limite adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaProximo : 
        window["n_" + g] += 1;
        $('#' + g + ' a.'+ galeriaAnterior).removeClass('inativo');
        if (window["n_" + g] == window["scrolls_" + g]) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        window["galeria_" + g].animate({
          'margin-left' : '-=' + window["largura_" + g] + 'px',
          'margin-right' : '-=' + window["largura_" + g] + 'px'
        }, velocidade);
        
        if(typeof paginacao != "undefined"){
          // insere a classe 'ativo' no item da paginacao correspondente ao clique
          $('#'+ g +' ol.'+ paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
        }
      break;
    }
  }
  
  // PAGINACAO - funcao para scroll na galeria
  function scrollPaginacao(i, g){
    
    // atualizando a variavel dos cliques
    window["n_" + g] = parseInt(i);
    
    if (window["n_" + g] == 0) { 
      $('#'+ g +' a.' + galeriaAnterior).addClass('inativo'); 
      $('#'+ g +' a.' + galeriaProximo).removeClass('inativo');
    } else if (window["n_" + g] > 0 || window["n_" + g] <= window["scrolls_" + g]) { 
      $('#'+ g +' a.' + galeriaAnterior).removeClass('inativo');
      $('#'+ g +' a.' + galeriaProximo).removeClass('inativo');
    }
    
    if (window["n_" + g] == window["scrolls_" + g]) { 
      $('#'+ g +' a.' + galeriaProximo).addClass('inativo');
    }
    
    window["galeria_" + g].animate({
      'margin-left' : '-' + window["largura_" + g] * i + 'px',
      'margin-right' : '-' + window["largura_" + g] * i + 'px'
    }, velocidade);
    
  }
  
  $(idGaleria +' a.'+ galeriaAnterior + ', '+ idGaleria +' a.' + galeriaProximo).click(function(){
    
    // se o link nao tiver a classe "inativo" executa a funcao da galeria
    if(!$(this).hasClass('inativo')){
      scrollGaleria($(this).attr('class'), $(this).parent().attr('id'));
    }
    return false;
    
  });
  
  if(typeof paginacao != "undefined"){
    $(idGaleria +' ol.'+ paginacao +' li a').click(function(){
      
      // id da galeria que envolve a paginacao clicada
      var id = $(this).parent().parent().parent().attr('id');
      
      // executa a funcao de scroll da paginacao
      scrollPaginacao($(this).parent().index(), id);
      
      // remove a classe ativo e insere no item especifico
      $('#' + id + ' ol.'+ paginacao +' li').removeClass('ativo');
      $(this).parent().addClass('ativo');
      
      return false;
      
    });
  }
  
});