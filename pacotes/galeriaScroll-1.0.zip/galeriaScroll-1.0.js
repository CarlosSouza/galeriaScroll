/*
  ----
    galeriaScroll v1.0
  ----
  
  INSTRUCOES:
  
  Declarar estas variaveis ANTES de chamar o script da galeria:
  
    idGaleria = '.galeria'; // identificador da galeria
    galeriaAnterior = 'anterior'; // classe para o link anterior
    galeriaProximo = 'proximo'; // classe para o link proximo
    itemGaleria = 'ul > li'; // elemento que contem cada item da galeria
    estruturaGaleria = '.mascara > ul'; // elemento que sera animado (com margin)
  
  OBSERVACOES:
    
    Usa-se a classe "inativo" para os elementos nao-clicaveis
*/

$(document).ready(function(){

  $(idGaleria).each(function(){
    
    // largura 100000px para nao quebrar a galeria em linhas
    $(estruturaGaleria, $(this)).css('width', '100000px');
    
    // inserindo os links de navegacao em cada galeria
    $(this).prepend('<a class="'+ galeriaAnterior +'" href="#" title="Anterior">Anterior</a> <a class="' + galeriaProximo + '" href="#" title="Próximo">Próximo</a>');
    
    // variavel com o valor do ID da galeria
    var g = $(this).attr('id');
    
    // criando variavel dinamica
    window["n_" + g] = 0;
    
    // limite de elementos a aparecer na tela, de acordo com a largura total / largura de cada item
    window["limite_" + g] = Math.ceil($(this).width() / $(itemGaleria, $(this)).outerWidth());
  
    // adicionando class "inativo" para o link anterior, alem de esconder o "proximo" se os itens forem <= que o limite
    $('a.' + galeriaAnterior, $(this)).addClass('inativo');
    var total = $(itemGaleria, $(this)).length;
    if (total <= window["limite_" + g]) $('a.'+ galeriaProximo, $(this)).addClass('inativo');
    
  });
  
  function scrollGaleria(direcao, g){
    
    // largura do elemento que envolve a galeria
    var largura = $('#'+ g).width();
    
    // elemento da galeria, dentro da galeria especifica
    var galeria = $(estruturaGaleria, '#'+ g);
    
    // quantidade de itens na galeria
    var total = $(itemGaleria, '#'+ g).length;
    
    // limite de scrolls
    var scrolls = Math.ceil(total / window["limite_" + g]) - 1;
    
    // velocidade da animacao em ms
    var velocidade = 250;
    
    switch (direcao){
    
      /* 
        Caso a direcao seja 'anterior' tira 1 da variavel a cada clique,
        retira a classe 'inativo' do link 'proximo',
        se a variavel dinamica for = 0 adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaAnterior : 
        window["n_" + g] -= 1;
        $('#' + g + ' a.'+ galeriaProximo).removeClass('inativo'); 
        if (window["n_" + g] == 0) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        galeria.animate({
          'margin-left' : '+=' + largura + 'px',
          'margin-right' : '+=' + largura + 'px'
        }, velocidade);
      break;
      
      /* 
        Caso a direcao seja 'proximo' soma 1 da variavel a cada clique,
        mostra o link 'anterior',
        se os cliques atingirem o limite adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaProximo : 
        window["n_" + g] += 1;
        $('#' + g + ' a.'+ galeriaAnterior).removeClass('inativo');
        if (window["n_" + g] == scrolls) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        galeria.animate({
          'margin-left' : '-=' + largura + 'px',
          'margin-right' : '-=' + largura + 'px'
        }, velocidade);
      break; 
    }
  }
  
  $(idGaleria +' a.'+ galeriaAnterior + ', '+ idGaleria +' a.' + galeriaProximo).click(function(){
    
    // se o link nao tiver a classe "inativo" executa a funcao da galeria
    if(!$(this).hasClass('inativo')){
      scrollGaleria($(this).attr('class'), $(this).parent().attr('id'));
    }
    return false;
    
  });
  
});