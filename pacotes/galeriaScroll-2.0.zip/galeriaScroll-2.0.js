/*
  ----
    galeriaScroll v2.0
  ----
  
  INSTRUCOES:
  
  Declarar estas variaveis ANTES de chamar o script da galeria:
  
    idGaleria = '.galeria'; // identificador da galeria
    galeriaAnterior = 'anterior'; // classe para o link anterior
    galeriaProximo = 'proximo'; // classe para o link proximo
    itemGaleria = 'ul > li'; // elemento que contem cada item da galeria
    estruturaGaleria = '.mascara > ul'; // elemento que sera animado (com margin)
    paginacao = 'paginacao'; // caso nao queira usar paginacao, apague esta linha
  
  OBSERVACOES:
    
    Classe "inativo" para os elementos nao-clicaveis
    Classe "ativo" para o item da paginacao atual
*/

$(document).ready(function(){

  $(idGaleria).each(function(){
    
    // largura 9999em para nao quebrar a galeria em linhas
    $(estruturaGaleria, $(this)).css('width', '9999em');
    
    // inserindo os links de navegacao em cada galeria
    $(this).prepend('<a class="'+ galeriaAnterior +'" href="#" title="Anterior">Anterior</a> <a class="' + galeriaProximo + '" href="#" title="Próximo">Próximo</a>');
    
    // variavel com o valor do ID da galeria
    gAtual = $(this).attr('id');
    
    // criando variavel dinamica
    window["n_" + gAtual] = 0;
    
    // limite de elementos a aparecer na tela, de acordo com a largura total / largura de cada item
    window["limite_" + gAtual] = Math.ceil($(this).width() / $(itemGaleria, $(this)).outerWidth());
  
    // adicionando class "inativo" para o link anterior, alem de esconder o "proximo" se os itens forem <= que o limite
    $('a.' + galeriaAnterior, $(this)).addClass('inativo');
    var total = $(itemGaleria, $(this)).length;
    if (total <= window["limite_" + gAtual]) $('a.'+ galeriaProximo, $(this)).addClass('inativo');
    
    // numero de scrolls possiveis
    limiteScrolls = Math.ceil(total / window["limite_" + gAtual]) - 1;
    
    // criacao da paginacao
    if(typeof paginacao != "undefined"){
      
      // insere o elemento <ol> para a paginacao
      $('#' + gAtual).append('<ol class="'+ paginacao +'"></ol>');
      
      // cria os elementos da paginacao de acordo com os scrolls
      var i = 0;
      for (i = 0; i <= limiteScrolls ; i++) {
        var texto = parseInt(i) + 1;
        $('ol.'+ paginacao, '#' + gAtual).append('<li><a href="#" title="Navegar na galeria">'+ texto +'</a></li>') 
      }
      
      // classe 'ativo' para o primeiro item da lista
      $('ol.'+ paginacao +' li:first', $(this)).addClass('ativo');
      
    };
    
  });
  
  // NAVEGACAO - funcao para scroll na galeria
  function scrollGaleria(direcao, g){
    
    // largura do elemento que envolve a galeria
    var largura = $('#'+ g).width();
    
    // elemento da galeria, dentro da galeria especifica
    var galeria = $(estruturaGaleria, '#'+ g);
    
    // quantidade de itens na galeria
    var total = $(itemGaleria, '#'+ g).length;
    
    // numero de scrolls possiveis
    var scrolls = Math.ceil(total / window["limite_" + g]) - 1;
    
    // ao clicar na navegacao, retira a classe 'ativo' de todos os itens da paginacao
    $('#'+ g +' ol.'+ paginacao +' li').removeClass('ativo');
    
    switch (direcao){
    
      /* 
        Caso a direcao seja 'anterior' tira 1 da variavel a cada clique,
        retira a classe 'inativo' do link 'proximo',
        se a variavel dinamica for = 0 adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaAnterior : 
        window["n_" + g] -= 1;
        $('#' + g + ' a.'+ galeriaProximo).removeClass('inativo'); 
        if (window["n_" + g] == 0) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        galeria.animate({
          'margin-left' : '+=' + largura + 'px',
          'margin-right' : '+=' + largura + 'px'
        }, velocidade);
        
        // insere a classe 'ativo' no item da paginacao correspondente ao clique
        $('#'+ g +' ol.'+ paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
      break;
      
      /* 
        Caso a direcao seja 'proximo' soma 1 da variavel a cada clique,
        mostra o link 'anterior',
        se os cliques atingirem o limite adiciona a class 'inativo',
        faz o efeito de scroll
      */
      
      case galeriaProximo : 
        window["n_" + g] += 1;
        $('#' + g + ' a.'+ galeriaAnterior).removeClass('inativo');
        if (window["n_" + g] == scrolls) { $('#'+ g +' a.' + direcao).addClass('inativo'); }
        
        galeria.animate({
          'margin-left' : '-=' + largura + 'px',
          'margin-right' : '-=' + largura + 'px'
        }, velocidade);
        
        // insere a classe 'ativo' no item da paginacao correspondente ao clique
        $('#'+ g +' ol.'+ paginacao +' li:eq('+ window["n_" + g] + ')').addClass('ativo');
      break;
    }
  }
  
  // PAGINACAO - funcao para scroll na galeria
  function scrollPaginacao(i, g){
    
    // quantidade de itens na galeria
    var total = $(itemGaleria, '#'+ g).length;
    
    // numero de scrolls possiveis
    var scrolls = Math.ceil(total / window["limite_" + g]) - 1;
    
    // atualizando a variavel dos cliques
    window["n_" + g] = parseInt(i);
    
    if (window["n_" + g] == 0) { 
      $('#'+ g +' a.' + galeriaAnterior).addClass('inativo'); 
      $('#'+ g +' a.' + galeriaProximo).removeClass('inativo');
    } else if (window["n_" + g] > 0 || window["n_" + g] <= scrolls) { 
      $('#'+ g +' a.' + galeriaAnterior).removeClass('inativo');
      $('#'+ g +' a.' + galeriaProximo).removeClass('inativo');
    }
    
    if (window["n_" + g] == scrolls) { 
      $('#'+ g +' a.' + galeriaProximo).addClass('inativo');
    }
    
    // largura do elemento que envolve a galeria
    var largura = $('#'+ g).width();
    
    // elemento da galeria, dentro da galeria especifica
    var galeria = $(estruturaGaleria, '#'+ g);
    
    galeria.animate({
      'margin-left' : '-' + largura * i + 'px',
      'margin-right' : '-' + largura * i + 'px'
    }, velocidade);
    
  }
  
  $(idGaleria +' a.'+ galeriaAnterior + ', '+ idGaleria +' a.' + galeriaProximo).click(function(){
    
    // se o link nao tiver a classe "inativo" executa a funcao da galeria
    if(!$(this).hasClass('inativo')){
      scrollGaleria($(this).attr('class'), $(this).parent().attr('id'));
    }
    return false;
    
  });
  
  $(idGaleria +' ol.'+ paginacao +' li a').click(function(){
    
    // id da galeria que envolve a paginacao clicada
    var id = $(this).parent().parent().parent().attr('id');
    
    // executa a funcao de scroll da paginacao
    scrollPaginacao($(this).parent().index(), id);
    
    // remove a classe ativo e insere no item especifico
    $('#' + id + ' ol.'+ paginacao +' li').removeClass('ativo');
    $(this).parent().addClass('ativo');
    
    return false;
    
  });
  
});